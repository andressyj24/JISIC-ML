Crear la carpeta del Workspace

Crear el directorio de trabajo
    $HOME
    export ML_PATH="$HOME/Documents/machine-learning"
    mkdir -p $ML_PATH

Verificar si esta instalado Pip3
    pip3 --version
    pip3 install --upgrade pip

CREATING AN ISOLATED ENVIRONMENT
    pip3 install --user --upgrade virtualenv
    cd $ML_PATH
    "sudo /usr/bin/easy_install virtualenv"
    virtualenv env

Para activar el ambiente virtual
    cd $ML_PATH
    source env/bin/activate

Install packages
    pip3 install --upgrade jupyter numpy pandas scikit-learn
Comprobar
    python3 -c "import jupyter, numpy, pandas, sklearn"
Abrir jupyter
    jupyter notebook



clave de la maquina USRDEL