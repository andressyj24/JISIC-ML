#Pandas

#---------Crear un DataFrame con Pandas a partir de un diccionario---------
# Pre-defined lists
names = ['United States', 'Australia', 'Japan', 'India', 'Russia', 'Morocco', 'Egypt']
dr =  [True, False, False, False, True, True, True]
cpc = [809, 731, 588, 18, 200, 70, 45]
# Import pandas as pd
import pandas as pd
# Create dictionary my_dict with three key:value pairs: my_dict
my_dict = {'country':names,'drives_right':dr, 'cars_per_cap':cpc}
# Build a DataFrame cars from my_dict: cars
cars = pd.DataFrame(my_dict) 
# Print cars
print(cars)

#----------Agregar una columna indice para cada una de las filas" 
# Definition of row_labels
row_labels = ['US', 'AUS', 'JAP', 'IN', 'RU', 'MOR', 'EG']
cars.index = row_labels
print(cars)

# ---- Leer de un csv, descargar el cars.csv --------
# https://drive.google.com/open?id=1D4VNKfenkezsvnZ9lSK_gZRQpBz4W2Yz
# Import pandas as pd
import pandas as pd
# Import the cars.csv data: cars
cars = pd.read_csv("cars.csv")
# Print out cars
print(cars)
# Fix import by including index_col
cars = pd.read_csv('cars.csv', index_col = 0)

#Seleccionar data
# Seleccion de columnas
# arreglo de una dimension
print(cars['mpg'])
print(type(cars['mpg']))
# DataFrame 
print(cars[['mpg']])
print(type(cars[['mpg']])) 
#podemos escoger dos columnas
print(cars[['mpg','hp']])

#Seleccion de filas
#Escoger las filas de la uno a la 4 (El indice empieza en 0, el ultimo no se incluye (4))
print(cars[1:4])
#Una forma de selccionar la fila mediante su etiqueta
print(cars.loc[["Mazda RX4"]])
#Para mas filas
print(cars.loc[["Mazda RX4","Toyota Corolla","Ferrari Dino"]])

#Seleccion de filas y columnas
print(cars.loc[["Mazda RX4","Toyota Corolla","Ferrari Dino"],["mpg","hp"]])
#Si quieren todas las filas
print(cars.loc[:,["mpg","hp"]])


#Si queremos usar el indice usamos iloc
print(cars.iloc[[0]])
print(cars.iloc[[0,12,20]])
print(cars.iloc[[0,12,20],[0,2]])



#SI FALTA TIEMPO
# Import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
# Make a line plot: year on the x-axis, pop on the y-axis
plt.scatter(cars.loc[:,["hp"]],cars.loc[:,["mpg"]])
# Display the plot with plt.show()
plt.show()


