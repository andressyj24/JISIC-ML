#Numpy

#ARRAY
# Create 2 lists con jugadores de basket con altura en metros y peso en Kg
height = [1.80, 2.15, 2.10, 2.10, 1.88]
weight = [75.4, 94.2, 93.6, 98.4, 68.7]
# Import the numpy package as np
import numpy as np
# Create a numpy array from baseball: np_baseball
np_height_m = np.array(height)
np_weight_kg = np.array(weight)
print(type(np_height_m))
bmi = np_weight_kg / (np_height_m ** 2)
print(bmi)
# Crear un arreglo con los que no están gorditos
light = np.array(bmi < 21)
# Print out light
print(light)
# Print out BMIs of all baseball players whose BMI is below 21
print(bmi[light])

#ARREGLO DE ARREGLOS
# Create baseball, a list of lists
baseball = [[1.80, 78.4],
            [2.15, 102.7],
            [2.10, 98.5],
            [1.88, 75.2]]
# Import numpy
import numpy as np
# Create a 2D numpy array from baseball: np_baseball
np_baseball = np.array(baseball)
# Print out the type of np_baseball
print(type(np_baseball))
# Print out the shape of np_baseball
print(np_baseball.shape)

# Imprimir la tercera fila
print(np_baseball[3,:])
# Seleccionar la columna de los pesos
print(np_baseball[:,1])
# La altura del tercer basebalista
print(np_baseball[2,0]) #!!!!!!!!!!!!!!!! Para ellos

#ESTADISTICA
# Imprimir el promedio de la altura
avg = np.mean(np_baseball[:,0])
print("Average: " + str(avg))
# Imprimir la mediana de la altura
med = np.median(np_baseball[:,0])
print("Median: " + str(med))
# Imprimir la desviación estandar de la altura ------una medida del grado de dispersión de los datos con respecto al valor promedio.
stddev = np.std(np_baseball[:,0])
print("Standard Deviation: " + str(stddev))
# Print out correlation between first and second column. Replace 'None'
corr = np.corrcoef(np_baseball[:,0],np_baseball[:,1]) # es una matriz de correlacion donde muetra la relacion que existe entre cada pareja de variables que va de 0 a 1
print("Correlation: " + str(corr))

#PARA ELLOS
# DADA UNA LISTA DE POSICIONES DE JUGADORES Y SUS ESTATURAS, CALCULAR LA MEDIA DE LAS ESTATURAS DE LOS JUGADORES QUE NO SEAN PORTEROS
positions = ['GK', 'M', 'A', 'D']
heights = [1.91, 1.84, 1.85, 1.80]
# Convert positions and heights to numpy arrays: np_positions, np_heights
np_positions = np.array(positions)
np_heights = np.array(heights)
# Heights of the other players: other_heights
other_heights = np_heights[np_positions != 'GK']
# Print out the median height of other players. Replace 'None'
print(np.median(other_heights))
